# StrangeAttractors
A R package for fast computing a couple of Strange Attractors
